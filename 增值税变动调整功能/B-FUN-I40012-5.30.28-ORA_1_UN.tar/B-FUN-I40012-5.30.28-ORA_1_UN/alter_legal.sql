/*
================================================================================
檔案代號:hsc_file
檔案名稱:新舊稅別對照檔
檔案目的:
上游檔案:
下游檔案:N
檔案類型:B
多語系檔案:N
============.========================.==========================================
*/
create table hsc_file
(
hsc01       varchar2(4) DEFAULT ' ' NOT NULL, /*舊稅別碼*/
hsc011      varchar2(1) DEFAULT ' ' NOT NULL, /*進/銷項*/
hsc02       varchar2(4),             /*新稅別碼                               */
hsc021      varchar2(1),             /*進/銷項                                */
hsc03       date,                    /*啟用日期                               */
hscacti     varchar2(1),             /*資料有效碼                             */
hscdate     date,                    /*最近修改日                             */
hscgrup     varchar2(10),            /*資料所有群                             */
hscmodu     varchar2(10),            /*資料更改者                             */
hscorig     varchar2(10),            /*資料建立部門                           */
hscoriu     varchar2(10),            /*資料建立者                             */
hscuser     varchar2(10)             /*資料所有者                             */
);

alter table hsc_file add  constraint hsc_pk primary key  (hsc01,hsc011) enable validate;
grant select on hsc_file to tiptopgp;
grant update on hsc_file to tiptopgp;
grant delete on hsc_file to tiptopgp;
grant insert on hsc_file to tiptopgp;
grant index on hsc_file to public;
grant select on hsc_file to ods;
