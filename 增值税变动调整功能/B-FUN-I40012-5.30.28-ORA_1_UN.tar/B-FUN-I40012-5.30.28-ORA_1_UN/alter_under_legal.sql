create synonym hsc_file for ds1.hsc_file;
